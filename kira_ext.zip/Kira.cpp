//The functions that are not mine are clearly labeled im not a c/c++/asm master so I just used premade functions

#include <windows.h>

//If these values are shared it only picks up messages like a app hook not a global
#pragma data_seg(".SHARDAT")
	HWND		m_hHwnd = 0;
	HHOOK		m_hHook = NULL;

	//HWND		s_hHwnd = 0;
	//HHOOK		s_hHook = NULL;
#pragma data_seg()

void WINAPI MouseHookInit(HWND objHWND, HHOOK hkHWND)
{
	m_hHwnd = objHWND;	//Object hwnd
	m_hHook = hkHWND;	//Hook hwnd
}

LRESULT CALLBACK MouseHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	if (nCode < 0) //Must pass along
	{
		return CallNextHookEx(m_hHook, nCode, wParam, lParam);
	}

	if (nCode == HC_ACTION) //Must process
	{
		if ((wParam >= 0xA0) & (wParam <= 0xA9)) //Didnt write this part
		{
			wParam = wParam + 352;
		}

		switch (wParam)
		{
			case WM_MOUSEMOVE:
				PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
				( (MOUSEHOOKSTRUCT*) lParam )->pt.x,
				( (MOUSEHOOKSTRUCT*) lParam )->pt.y));

				break;
		}
	}

	return 0;
}

/*void WINAPI ShellHookInit(HWND objHWND, HHOOK hkHWND)
{
	s_hHwnd = objHWND;	//Object hwnd
	s_hHook = hkHWND;	//Hook hwnd
}

LRESULT CALLBACK ShellHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	if (nCode < 0)
	{
		return CallNextHookEx(s_hHook, nCode, wParam, lParam);
	}

	if (nCode == HC_ACTION) //Must process
	{
		PostMessage(s_hHwnd, nCode, wParam, lParam);
	}

	return 0;
}
*/

//Cut n paste stuff here
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID) {
	if (fdwReason == DLL_PROCESS_ATTACH) 
	{
		DisableThreadLibraryCalls(hinstDLL);
	}

	return TRUE;
}

// This is to prevent the CRT from loading, thus making this a smaller and faster dll.
extern "C" BOOL __stdcall _DllMainCRTStartup( HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) 
{
    return DllMain(hinstDLL, fdwReason, lpvReserved);
}
